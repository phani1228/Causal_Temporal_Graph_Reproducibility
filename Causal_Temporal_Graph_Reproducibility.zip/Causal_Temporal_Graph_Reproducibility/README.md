# Causal Temporal Graph Reproducibility Package

This package supports the Objective-1 dynamic multiplex stock-relationship graph study over **40 quarterly snapshots (2016Q1-2025Q4)**.

## Canonical parameters
- Market: `L=60`, `|rho| >= 0.60`, top-k=10, signed Pearson weight.
- Financial: cross-sectional median imputation, 1st/99th percentile winsorization, snapshot z-score standardization, cosine >= 0.80, top-k=10.
- Macro: `H=20` quarters, ridge `alpha=1.0` (intercept unpenalized), exposure cosine >= 0.85, top-k=10.
- Directed top-k choices are converted to an undirected graph using symmetric union.
- Robustness grid: theta_m in {0.40,0.50,0.60,0.70}, k in {5,10,15}, L in {30,60,90} = 36 configurations x 40 snapshots = 1,440 graphs.

## Contents
- `data/`: concatenated nodes and relation-specific baseline edge outputs plus `parameters.json`.
- `validation/`: snapshot-level graph validation, relation summaries, and 2025Q4 metrics.
- `temporal_stability/`: adjacent-snapshot stability results.
- `sensitivity/`: 1,440-graph robustness table and marginal sensitivity summaries.
- `statistical_tests/`: quarter-matched non-parametric sensitivity tests.
- `code/`: Algorithms 1-3 and figure-generation code.
- `figures/`: graph evolution, final-snapshot community structure, and robustness summary.

## Raw input
The large source panel is intentionally not duplicated in this archive. The scripts expect the master CSV used in the study (for example `NIFTY500_Master_Dataset_2016_2025.csv`) to be supplied via `--input`.

## Execution order
1. `python code/algorithm1_dynamic_multiplex_graph.py --input <MASTER.csv> --output outputs`
2. `python code/algorithm3_robustness_analysis.py --input <MASTER.csv> --package-root .`
3. `python code/generate_figures.py --package-root .`

`algorithm2_macro_sensitivity.py` contains the standalone rolling ridge-exposure construction used conceptually by Algorithm 1.

## Reproducibility note
The baseline data files in this archive were regenerated from the saved master dataset available to this project. The package does not claim a repository DOI until it is deposited in Zenodo/Figshare/Mendeley Data or another permanent repository.
