from __future__ import annotations
import argparse
from pathlib import Path
import numpy as np, pandas as pd, networkx as nx
from scipy import stats

THETAS=[0.40,0.50,0.60,0.70]; KS=[5,10,15]; LS=[30,60,90]
METRICS=["edge_count","density","mean_degree","clustering_coefficient","connected_components","largest_component_ratio","node_coverage","modularity"]
def pkey(p): return (int(str(p)[:4]),int(str(p)[-1]))
def sym_topk(corr,theta,k):
    syms=corr.index.to_list(); A=corr.to_numpy(float); chosen={}
    for i,s in enumerate(syms):
        row=A[i].copy(); row[i]=np.nan; score=np.abs(row)
        cand=np.flatnonzero(np.isfinite(score)&(score>=theta))
        if cand.size:
            cand=cand[np.argsort(score[cand])[::-1][:k]]
            for j in cand:
                pair=tuple(sorted((s,syms[j]))); w=float(row[j])
                if pair not in chosen or abs(w)>abs(chosen[pair]): chosen[pair]=w
    return list(chosen.keys())
def gmetrics(nodes,edges):
    G=nx.Graph(); G.add_nodes_from(nodes); G.add_edges_from(edges)
    n=G.number_of_nodes(); e=G.number_of_edges(); comps=list(nx.connected_components(G)); l=max((len(c) for c in comps),default=0)
    if e:
        try: mod=nx.community.modularity(G,nx.community.louvain_communities(G,seed=42))
        except Exception: mod=np.nan
    else: mod=np.nan
    return dict(edge_count=e,density=nx.density(G) if n>1 else 0.0,mean_degree=2*e/n if n else np.nan,
                clustering_coefficient=nx.average_clustering(G) if n else np.nan,connected_components=len(comps),
                largest_component_ratio=l/n if n else np.nan,node_coverage=sum(G.degree(x)>0 for x in G)/n if n else np.nan,modularity=mod)
def main(inp,root):
    use=["Date","Quarter_End_Date","Period","Symbol","Log_Return"]
    df=pd.read_csv(inp,usecols=use)
    df["Date"]=pd.to_datetime(df["Date"],errors="coerce")
    df["Quarter_End_Date"]=pd.to_datetime(df["Quarter_End_Date"],errors="coerce")
    df=df.dropna(subset=["Date","Period","Symbol"]).sort_values(["Date","Symbol"]).drop_duplicates(["Date","Symbol"])
    periods=sorted(df.Period.astype(str).unique(),key=pkey)
    qends=df.groupby("Period")["Quarter_End_Date"].max().to_dict()
    nodes_by_period={p:sorted(df.loc[df.Period.astype(str).eq(p),"Symbol"].astype(str).unique()) for p in periods}
    panel=df.pivot(index="Date",columns="Symbol",values="Log_Return").sort_index()
    rows=[]
    for period in periods:
        qend=qends[period]; nodes=nodes_by_period[period]
        psub=panel.loc[:qend,nodes]
        for L in LS:
            win=psub.tail(L); minobs=max(20,int(L*2/3)); eligible=win.count(); cols=eligible[eligible>=minobs].index
            corr=win[cols].corr(min_periods=minobs)
            for th in THETAS:
                for k in KS:
                    m=gmetrics(nodes,sym_topk(corr,th,k)); m.update(period=period,theta_m=th,k=k,L=L); rows.append(m)
    out=pd.DataFrame(rows)
    baseline=out[(out.theta_m==0.60)&(out.k==10)&(out.L==60)][["period",*METRICS]].set_index("period")
    for m in METRICS: out[m+"_contrast_baseline"]=[r[m]-baseline.loc[r.period,m] for _,r in out.iterrows()]
    out.to_csv(Path(root)/"sensitivity"/"robustness_1440_graphs.csv",index=False)
    sens=[]; tests=[]
    for factor,levels in [("theta_m",THETAS),("k",KS),("L",LS)]:
        marg=out.groupby(["period",factor],as_index=False)[METRICS].mean()
        for metric in METRICS:
            for lv,g in marg.groupby(factor): sens.append(dict(factor=factor,level=lv,metric=metric,mean=g[metric].mean(),std=g[metric].std(ddof=1),n=len(g)))
            piv=marg.pivot(index="period",columns=factor,values=metric).dropna(); arrays=[piv[c].to_numpy() for c in sorted(piv.columns)]
            if len(arrays)>=3 and len(piv)>=2:
                stat,p=stats.friedmanchisquare(*arrays); W=stat/(len(piv)*(len(arrays)-1))
            else: stat=p=W=np.nan
            tests.append(dict(factor=factor,metric=metric,test="Friedman",statistic=stat,p_value=p,kendalls_W=W,n_quarters=len(piv),n_levels=len(arrays)))
    pd.DataFrame(sens).to_csv(Path(root)/"sensitivity"/"sensitivity_analysis.csv",index=False)
    pd.DataFrame(tests).to_csv(Path(root)/"statistical_tests"/"statistical_tests.csv",index=False)
if __name__=="__main__":
    ap=argparse.ArgumentParser(); ap.add_argument("--input",required=True); ap.add_argument("--package-root",required=True); a=ap.parse_args(); main(a.input,a.package_root)
