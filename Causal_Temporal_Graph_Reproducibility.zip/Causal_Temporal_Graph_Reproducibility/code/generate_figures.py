from pathlib import Path
import argparse, pandas as pd, networkx as nx, matplotlib.pyplot as plt
def main(root):
 r=Path(root); val=pd.read_csv(r/"validation"/"snapshot_validation_metrics.csv"); u=val[val.relation=="union"].copy();
 plt.figure(figsize=(9,5)); plt.plot(u.period,u.edge_count,marker="o",ms=3); plt.xticks(rotation=90); plt.ylabel("Union edges"); plt.xlabel("Quarter"); plt.tight_layout(); plt.savefig(r/"figures"/"graph_evolution.png",dpi=200); plt.close()
 nodes=pd.read_csv(r/"data"/"nodes.csv"); ed=[]
 for fn in ["edges_sector.csv","edges_market.csv","edges_financial.csv","edges_macro.csv"]:
  x=pd.read_csv(r/"data"/fn); ed.append(x[x.period=="2025Q4"][["source","target"]])
 E=pd.concat(ed).drop_duplicates(); N=nodes[nodes.period=="2025Q4"]; G=nx.Graph(); G.add_nodes_from(N.Symbol.astype(str)); G.add_edges_from(E.itertuples(index=False,name=None)); pos=nx.spring_layout(G,seed=42);
 plt.figure(figsize=(9,7)); nx.draw_networkx_nodes(G,pos,node_size=12); nx.draw_networkx_edges(G,pos,width=.25,alpha=.35); plt.axis("off"); plt.tight_layout(); plt.savefig(r/"figures"/"community_structure.png",dpi=200); plt.close()
 rob=pd.read_csv(r/"sensitivity"/"robustness_1440_graphs.csv"); s=rob.groupby("theta_m",as_index=False).density.mean(); plt.figure(figsize=(7,5)); plt.plot(s.theta_m,s.density,marker="o"); plt.xlabel("Market threshold θm"); plt.ylabel("Mean density"); plt.tight_layout(); plt.savefig(r/"figures"/"robustness_results.png",dpi=200); plt.close()
if __name__=="__main__":
 ap=argparse.ArgumentParser(); ap.add_argument("--package-root",default="."); a=ap.parse_args(); main(a.package_root)
