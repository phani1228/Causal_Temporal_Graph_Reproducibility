from __future__ import annotations
import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler

def build_macro_sensitivity_layer(stock_returns: pd.DataFrame, macro_factors: pd.DataFrame, snapshot_pos: int, H: int=20, alpha: float=1.0, theta_mac: float=0.85, k: int=10):
    start=snapshot_pos-H+1
    if start < 0: return pd.DataFrame(columns=["source","target","relation","weight"]), {}
    Xdf=macro_factors.iloc[start:snapshot_pos+1].copy()
    if len(Xdf)!=H or Xdf.isna().any().any(): return pd.DataFrame(columns=["source","target","relation","weight"]), {}
    X=StandardScaler().fit_transform(Xdf.to_numpy(float))
    betas={}
    for symbol in stock_returns.columns:
        y=stock_returns.iloc[start:snapshot_pos+1][symbol].to_numpy(float)
        mask=np.isfinite(y)
        if mask.sum()!=H: continue
        model=Ridge(alpha=alpha,fit_intercept=True).fit(X[mask],y[mask])
        betas[symbol]=model.coef_.astype(float)
    syms=list(betas)
    if len(syms)<2: return pd.DataFrame(columns=["source","target","relation","weight"]), betas
    B=np.vstack([betas[s] for s in syms]); norms=np.linalg.norm(B,axis=1,keepdims=True)
    B=np.divide(B,norms,out=np.zeros_like(B),where=norms!=0); sim=B@B.T
    chosen={}
    for i,s in enumerate(syms):
        row=sim[i].copy(); row[i]=np.nan; cand=np.flatnonzero(np.isfinite(row)&(row>=theta_mac))
        cand=cand[np.argsort(row[cand])[::-1][:k]]
        for j in cand:
            pair=tuple(sorted((s,syms[j]))); chosen[pair]=max(chosen.get(pair,-np.inf),float(row[j]))
    edges=pd.DataFrame([{"source":a,"target":b,"relation":"macro_sensitivity","weight":w} for (a,b),w in chosen.items()])
    return edges, betas
