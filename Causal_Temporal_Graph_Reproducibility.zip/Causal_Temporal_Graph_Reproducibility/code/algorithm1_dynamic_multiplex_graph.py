"""Dynamic heterogeneous stock-graph construction.

Input
-----
Master_Heterogeneous_Graph_Dataset(3).csv

Output (per quarter)
--------------------
outputs/<period>/nodes.csv
outputs/<period>/edges_sector.csv
outputs/<period>/edges_market.csv
outputs/<period>/edges_financial.csv
outputs/<period>/edges_macro.csv
outputs/<period>/edges_union.csv
outputs/graph_summary.csv

Relations
---------
1. Same-sector binary relation.
2. Rolling market-correlation relation (signed Pearson weight).
3. Financial-feature cosine-similarity relation.
4. Macroeconomic-sensitivity cosine-similarity relation.

The code uses only observations available on or before each quarter end.
"""

from __future__ import annotations

import argparse
import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable

import networkx as nx
import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.impute import SimpleImputer
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler


FINANCIAL_FEATURES = [
    "Revenue_Cr", "Net_Profit_Cr", "EPS", "PE_Ratio", "PB_Ratio",
    "ROE_Pct", "ROCE_Pct", "Debt_to_Equity", "Net_Profit_Margin_Pct",
    "Free_Cash_Flow_Cr", "Book_Value_Per_Share", "Avg_Close_Price",
]

MACRO_FEATURES = [
    "GDP_Growth_YoY_Pct", "CPI_Inflation_YoY_Pct",
    "WPI_Inflation_YoY_Pct", "RBI_Repo_Rate_Pct",
    "10Y_GSec_Yield_Pct", "USD_INR_Avg", "IIP_Growth_YoY_Pct",
    "Brent_Crude_USD_per_bbl", "Forex_Reserves_USD_Bn",
    "Fiscal_Deficit_Pct_GDP", "PMI_Manufacturing",
]


@dataclass(frozen=True)
class GraphParameters:
    market_window: int = 60
    min_return_observations: int = 40
    market_threshold: float = 0.60
    financial_threshold: float = 0.80
    macro_threshold: float = 0.85
    top_k: int = 10
    macro_lookback_quarters: int = 20
    macro_min_history: int = 4
    ridge_alpha: float = 1.0
    max_macro_components: int = 5


def period_key(period: str) -> tuple[int, int]:
    year, quarter = period.split("Q")
    return int(year), int(quarter)


def prepare_data(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    required = {
        "Date", "Quarter_End_Date", "Period", "Symbol", "Company_Name",
        "Sector", "Adj Close", "Log_Return", *FINANCIAL_FEATURES,
        *MACRO_FEATURES,
    }
    missing = sorted(required.difference(df.columns))
    if missing:
        raise ValueError(f"Missing required columns: {missing}")

    df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
    df["Quarter_End_Date"] = pd.to_datetime(df["Quarter_End_Date"], errors="coerce")
    df["Symbol"] = df["Symbol"].astype(str).str.strip()
    df["Period"] = df["Period"].astype(str).str.strip()
    df = df.dropna(subset=["Date", "Quarter_End_Date", "Period", "Symbol"])
    df = df.sort_values(["Date", "Symbol"]).drop_duplicates(["Date", "Symbol"])
    return df


def latest_snapshot(df: pd.DataFrame, period: str, columns: list[str]) -> pd.DataFrame:
    q = df.loc[df["Period"].eq(period), columns].copy()
    q = q.sort_values("Date").groupby("Symbol", as_index=False).tail(1)
    return q.set_index("Symbol")


def make_nodes(df: pd.DataFrame, period: str) -> pd.DataFrame:
    cols = ["Date", "Symbol", "Company_Name", "Sector", "Industry"]
    cols = [c for c in cols if c in df.columns]
    nodes = latest_snapshot(df, period, cols).reset_index()
    nodes.insert(0, "node_id", np.arange(len(nodes), dtype=int))
    nodes.insert(1, "period", period)
    return nodes


def symmetric_top_k_edges(
    similarity: pd.DataFrame,
    threshold: float,
    top_k: int,
    relation: str,
    use_absolute_threshold: bool = False,
) -> pd.DataFrame:
    """Threshold, directed top-k selection, then symmetric union and deduplication."""
    symbols = similarity.index.to_list()
    values = similarity.to_numpy(dtype=float)
    selected: dict[tuple[str, str], float] = {}

    for i, source in enumerate(symbols):
        row = values[i].copy()
        row[i] = np.nan
        score = np.abs(row) if use_absolute_threshold else row
        candidates = np.flatnonzero(np.isfinite(score) & (score >= threshold))
        if candidates.size == 0:
            continue
        ranked = candidates[np.argsort(score[candidates])[::-1][:top_k]]
        for j in ranked:
            target = symbols[j]
            pair = tuple(sorted((source, target)))
            weight = float(row[j])
            # If selected from both directions, retain the value with greater magnitude.
            if pair not in selected or abs(weight) > abs(selected[pair]):
                selected[pair] = weight

    rows = [
        {"source": a, "target": b, "relation": relation, "weight": w}
        for (a, b), w in selected.items()
    ]
    return pd.DataFrame(rows, columns=["source", "target", "relation", "weight"])


def sector_edges(nodes: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict] = []
    for _, group in nodes.dropna(subset=["Sector"]).groupby("Sector"):
        symbols = sorted(group["Symbol"].unique())
        for i in range(len(symbols)):
            for j in range(i + 1, len(symbols)):
                rows.append({
                    "source": symbols[i], "target": symbols[j],
                    "relation": "sector", "weight": 1.0,
                })
    return pd.DataFrame(rows, columns=["source", "target", "relation", "weight"])


def market_edges(
    df: pd.DataFrame,
    period: str,
    node_symbols: Iterable[str],
    p: GraphParameters,
) -> pd.DataFrame:
    quarter_end = df.loc[df["Period"].eq(period), "Quarter_End_Date"].max()
    history = df.loc[
        (df["Date"] <= quarter_end) & df["Symbol"].isin(node_symbols),
        ["Date", "Symbol", "Log_Return"],
    ].copy()
    # Last L valid observations for every stock, ending at snapshot t.
    history = history.dropna(subset=["Log_Return"])
    history = history.groupby("Symbol", group_keys=False).tail(p.market_window)
    counts = history.groupby("Symbol")["Log_Return"].count()
    eligible = counts[counts >= p.min_return_observations].index
    panel = history.loc[history["Symbol"].isin(eligible)].pivot(
        index="Date", columns="Symbol", values="Log_Return"
    )
    corr = panel.corr(min_periods=p.min_return_observations)
    return symmetric_top_k_edges(
        corr, p.market_threshold, p.top_k, "market_correlation", True
    )


def financial_edges(
    df: pd.DataFrame,
    period: str,
    node_symbols: Iterable[str],
    p: GraphParameters,
) -> pd.DataFrame:
    snap = latest_snapshot(
        df, period, ["Date", "Symbol", *FINANCIAL_FEATURES]
    ).reindex(list(node_symbols))
    x = SimpleImputer(strategy="median").fit_transform(snap[FINANCIAL_FEATURES])
    x = StandardScaler().fit_transform(x)
    norms = np.linalg.norm(x, axis=1, keepdims=True)
    x = np.divide(x, norms, out=np.zeros_like(x), where=norms != 0)
    sim = pd.DataFrame(x @ x.T, index=snap.index, columns=snap.index)
    return symmetric_top_k_edges(
        sim, p.financial_threshold, p.top_k, "financial_similarity", False
    )


def quarterly_stock_returns(df: pd.DataFrame) -> pd.DataFrame:
    prices = (
        df.sort_values("Date")
        .groupby(["Period", "Symbol"], as_index=False)
        .agg(first_price=("Adj Close", "first"), last_price=("Adj Close", "last"))
    )
    prices["quarter_return"] = np.log(prices["last_price"] / prices["first_price"])
    return prices.pivot(index="Period", columns="Symbol", values="quarter_return")


def quarterly_macro(df: pd.DataFrame) -> pd.DataFrame:
    macro = (
        df.sort_values("Date")
        .groupby("Period", as_index=True)[MACRO_FEATURES]
        .last()
        .sort_index(key=lambda idx: idx.map(period_key))
    )
    # Sensitivities are estimated against quarter-to-quarter changes.
    return macro.diff()


def macro_edges(
    stock_qret: pd.DataFrame,
    macro_qchange: pd.DataFrame,
    periods: list[str],
    period: str,
    node_symbols: Iterable[str],
    p: GraphParameters,
) -> pd.DataFrame:
    pos = periods.index(period)
    start = max(0, pos - p.macro_lookback_quarters + 1)
    hist_periods = periods[start:pos + 1]
    if len(hist_periods) < p.macro_min_history + 1:
        return pd.DataFrame(columns=["source", "target", "relation", "weight"])

    Xdf = macro_qchange.reindex(hist_periods)
    symbols = list(node_symbols)
    Ydf = stock_qret.reindex(hist_periods, columns=symbols)
    valid_rows = Xdf.notna().all(axis=1)
    Xdf, Ydf = Xdf.loc[valid_rows], Ydf.loc[valid_rows]
    if len(Xdf) < p.macro_min_history:
        return pd.DataFrame(columns=["source", "target", "relation", "weight"])

    X = SimpleImputer(strategy="median").fit_transform(Xdf)
    X = StandardScaler().fit_transform(X)
    n_components = min(p.max_macro_components, X.shape[1], max(1, X.shape[0] - 2))
    Xp = PCA(n_components=n_components, random_state=42).fit_transform(X)

    betas, kept = [], []
    for symbol in symbols:
        y = Ydf[symbol].to_numpy(dtype=float)
        mask = np.isfinite(y)
        if mask.sum() < p.macro_min_history:
            continue
        model = Ridge(alpha=p.ridge_alpha, fit_intercept=True)
        model.fit(Xp[mask], y[mask])
        betas.append(model.coef_)
        kept.append(symbol)

    if len(kept) < 2:
        return pd.DataFrame(columns=["source", "target", "relation", "weight"])

    B = np.asarray(betas, dtype=float)
    norms = np.linalg.norm(B, axis=1, keepdims=True)
    B = np.divide(B, norms, out=np.zeros_like(B), where=norms != 0)
    sim = pd.DataFrame(B @ B.T, index=kept, columns=kept)
    return symmetric_top_k_edges(
        sim, p.macro_threshold, p.top_k, "macro_sensitivity", False
    )


def graph_metrics(nodes: pd.DataFrame, edges: pd.DataFrame) -> dict:
    g = nx.Graph()
    g.add_nodes_from(nodes["Symbol"])
    g.add_edges_from(edges[["source", "target"]].itertuples(index=False, name=None))
    n = g.number_of_nodes()
    components = list(nx.connected_components(g)) if n else []
    largest = max((len(c) for c in components), default=0)
    return {
        "nodes": n,
        "edges": g.number_of_edges(),
        "density": nx.density(g) if n > 1 else 0.0,
        "average_degree": (2 * g.number_of_edges() / n) if n else 0.0,
        "average_clustering": nx.average_clustering(g) if n > 1 else 0.0,
        "connected_components": len(components),
        "isolated_nodes": nx.number_of_isolates(g),
        "largest_component_ratio": largest / n if n else 0.0,
    }


def construct_all(input_csv: Path, output_dir: Path, p: GraphParameters) -> None:
    df = prepare_data(input_csv)
    periods = sorted(df["Period"].unique(), key=period_key)
    stock_qret = quarterly_stock_returns(df).reindex(periods)
    macro_qchange = quarterly_macro(df).reindex(periods)
    output_dir.mkdir(parents=True, exist_ok=True)

    summary_rows: list[dict] = []
    for period in periods:
        period_dir = output_dir / period
        period_dir.mkdir(parents=True, exist_ok=True)
        nodes = make_nodes(df, period)
        symbols = nodes["Symbol"].tolist()

        relation_frames = {
            "sector": sector_edges(nodes),
            "market": market_edges(df, period, symbols, p),
            "financial": financial_edges(df, period, symbols, p),
            "macro": macro_edges(stock_qret, macro_qchange, periods, period, symbols, p),
        }
        nodes.to_csv(period_dir / "nodes.csv", index=False)
        for name, edge_df in relation_frames.items():
            edge_df.insert(0, "period", period)
            edge_df.to_csv(period_dir / f"edges_{name}.csv", index=False)

        multiplex = pd.concat(relation_frames.values(), ignore_index=True)
        multiplex.to_csv(period_dir / "edges_multiplex.csv", index=False)

        # Unique-pair projection for simple graph statistics. Multiple relation
        # types for the same pair are collapsed, while relation_count is retained.
        if multiplex.empty:
            union = pd.DataFrame(columns=["period", "source", "target", "relation_count", "relations"])
        else:
            union = (
                multiplex.groupby(["period", "source", "target"], as_index=False)
                .agg(
                    relation_count=("relation", "nunique"),
                    relations=("relation", lambda s: "|".join(sorted(set(s)))),
                )
            )
        union.to_csv(period_dir / "edges_union.csv", index=False)

        for name, edge_df in relation_frames.items():
            m = graph_metrics(nodes, edge_df)
            summary_rows.append({"period": period, "relation": name, **m})
        summary_rows.append({"period": period, "relation": "union", **graph_metrics(nodes, union)})
        print(f"{period}: nodes={len(nodes)}, multiplex_edges={len(multiplex)}, union_edges={len(union)}")

    pd.DataFrame(summary_rows).to_csv(output_dir / "graph_summary.csv", index=False)
    with (output_dir / "parameters.json").open("w", encoding="utf-8") as f:
        json.dump(asdict(p), f, indent=2)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Construct quarterly heterogeneous stock graphs")
    parser.add_argument("--input", type=Path, required=True, help="Master CSV path")
    parser.add_argument("--output", type=Path, default=Path("graph_outputs"))
    parser.add_argument("--market-window", type=int, default=60)
    parser.add_argument("--min-return-observations", type=int, default=40)
    parser.add_argument("--market-threshold", type=float, default=0.60)
    parser.add_argument("--financial-threshold", type=float, default=0.80)
    parser.add_argument("--macro-threshold", type=float, default=0.85)
    parser.add_argument("--top-k", type=int, default=10)
    parser.add_argument("--macro-lookback-quarters", type=int, default=20)
    parser.add_argument("--macro-min-history", type=int, default=4)
    args = parser.parse_args()

    params = GraphParameters(
        market_window=args.market_window,
        min_return_observations=args.min_return_observations,
        market_threshold=args.market_threshold,
        financial_threshold=args.financial_threshold,
        macro_threshold=args.macro_threshold,
        top_k=args.top_k,
        macro_lookback_quarters=args.macro_lookback_quarters,
        macro_min_history=args.macro_min_history,
    )
    construct_all(args.input, args.output, params)
